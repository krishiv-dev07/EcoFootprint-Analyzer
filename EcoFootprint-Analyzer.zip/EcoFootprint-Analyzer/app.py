import streamlit as st
import pandas as pd
import joblib
import os
from openai import OpenAI

# =========================
# Load trained artifacts
# =========================
rf_model = joblib.load("rf_model.pkl")
X_columns = joblib.load("X_columns.pkl")
y_series = joblib.load("target_series.pkl")


# =========================
# Helper functions
# =========================
def footprint_level(pred, y):
    if pred > y.quantile(0.75):
        return "high"
    elif pred > y.median():
        return "moderate"
    else:
        return "low"

def get_top_features(model, cols, n=5):
    return (
        pd.Series(model.feature_importances_, index=cols)
        .sort_values(ascending=False)
        .head(n)
    )

def generate_ai_explanation(prediction, level, top_features):
    prompt = f"""
A user has a {level} carbon footprint score of {prediction:.2f}.

Key contributing factors:
{top_features.to_string()}

Explain this simply for a high school student.
Give 2–3 practical suggestions to reduce emissions.
Keep under 120 words.
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5
    )
    return response.choices[0].message.content

# =========================
# Streamlit UI
# =========================
st.set_page_config(page_title="EcoFootprint Analyzer", page_icon="🌍")
st.title("🌍 EcoFootprint Analyzer")

st.markdown(
    "Estimate your carbon footprint using **Machine Learning** and "
    "understand it with **Generative AI**."
)

# =========================
# User Inputs
# =========================
st.header("Lifestyle Details")

# Numeric inputs
grocery = st.slider("Monthly grocery bill ($)", 50, 1000, 300)
vehicle_km = st.slider("Vehicle distance per month (km)", 0, 3000, 300)
waste = st.slider("Waste bags per week", 0, 10, 2)
clothes = st.slider("New clothes bought per month", 0, 10, 1)
internet = st.slider("Daily internet usage (hours)", 0.0, 12.0, 4.0)
screen = st.slider("Daily TV / PC usage (hours)", 0.0, 12.0, 3.0)

# Categorical inputs
diet = st.selectbox(
    "Diet type",
    ["Mixed", "Vegetarian", "Vegan", "Pescatarian"]
)

transport = st.selectbox(
    "Primary transport mode",
    ["Car", "Public Transport", "Walk/Bicycle"]
)

vehicle_type = st.selectbox(
    "Vehicle type",
    ["None", "Petrol", "Hybrid", "Electric", "LPG"]
)

energy_eff = st.selectbox(
    "Do you use energy-efficient appliances?",
    ["No", "Sometimes", "Yes"]
)

air_travel = st.selectbox(
    "Air travel frequency",
    ["Never", "Rarely", "Very Frequently"]
)

social = st.selectbox(
    "Social activity frequency",
    ["Rarely", "Sometimes", "Often"]
)

# Multi-select inputs
recycling = st.multiselect(
    "Recycling materials",
    ["Paper", "Plastic", "Glass", "Metal"]
)

cooking = st.multiselect(
    "Cooking appliances used",
    ["Stove", "Oven", "Microwave", "Grill", "Airfryer"]
)

# =========================
# Prediction
# =========================
if st.button("Analyze Footprint"):

    # Start with ALL zeros
    user_df = pd.DataFrame(0, index=[0], columns=X_columns)

    # -------- Numeric features --------
    user_df["Monthly Grocery Bill"] = grocery
    user_df["Vehicle Monthly Distance Km"] = vehicle_km
    user_df["Waste Bag Weekly Count"] = waste
    user_df["How Many New Clothes Monthly"] = clothes
    user_df["How Long Internet Daily Hour"] = internet
    user_df["How Long TV PC Daily Hour"] = screen

    # -------- Diet (baseline = Mixed) --------
    if diet == "Vegan":
        user_df["Diet_vegan"] = 1
    elif diet == "Vegetarian":
        user_df["Diet_vegetarian"] = 1
    elif diet == "Pescatarian":
        user_df["Diet_pescatarian"] = 1

    # -------- Transport (baseline = Car) --------
    if transport == "Public Transport":
        user_df["Transport_public"] = 1
    elif transport == "Walk/Bicycle":
        user_df["Transport_walk/bicycle"] = 1

    # -------- Vehicle Type (baseline = None) --------
    if vehicle_type == "Petrol":
        user_df["Vehicle Type_petrol"] = 1
    elif vehicle_type == "Hybrid":
        user_df["Vehicle Type_hybrid"] = 1
    elif vehicle_type == "Electric":
        user_df["Vehicle Type_electric"] = 1
    elif vehicle_type == "LPG":
        user_df["Vehicle Type_lpg"] = 1

    # -------- Energy Efficiency (baseline = No) --------
    if energy_eff == "Yes":
        user_df["Energy efficiency_Yes"] = 1
    elif energy_eff == "Sometimes":
        user_df["Energy efficiency_Sometimes"] = 1

    # -------- Air Travel (NO baseline) --------
    if air_travel == "Never":
        user_df["Frequency of Traveling by Air_never"] = 1
    elif air_travel == "Rarely":
        user_df["Frequency of Traveling by Air_rarely"] = 1
    elif air_travel == "Very Frequently":
        user_df["Frequency of Traveling by Air_very frequently"] = 1

    # -------- Social Activity (baseline = Rarely) --------
    if social == "Sometimes":
        user_df["Social Activity_sometimes"] = 1
    elif social == "Often":
        user_df["Social Activity_often"] = 1

    # -------- Recycling (exact column match) --------
    recycling_col = f"Recycling_{sorted(recycling)}"
    if recycling_col in X_columns:
        user_df[recycling_col] = 1

    # -------- Cooking (exact column match) --------
    cooking_col = f"Cooking_With_{sorted(cooking)}"
    if cooking_col in X_columns:
        user_df[cooking_col] = 1

    # -------- Prediction --------
    prediction = rf_model.predict(user_df)[0]
    level = footprint_level(prediction, y_series)
    top_features = get_top_features(rf_model, X_columns)

    # =========================
    # Results
    # =========================
    st.header("Results")
    st.metric("Predicted Carbon Footprint", round(prediction, 2))

    if level == "high":
        st.error("🔴 High Carbon Footprint")
    elif level == "moderate":
        st.warning("🟡 Moderate Carbon Footprint")
    else:
        st.success("🟢 Low Carbon Footprint")

    st.subheader("Top Contributing Factors")
    st.bar_chart(top_features)

    st.subheader("AI Explanation & Suggestions")
    st.write(generate_ai_explanation(prediction, level, top_features))
